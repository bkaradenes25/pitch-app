import { useEffect, useState } from "react";

const API = "http://127.0.0.1:8000";
const DEMO = [[0, 0], [0, 1], [1, 1], [1, 2], [2, 2]]; // scripted at-bat (balls, strikes)
const pct = (p) => `${(p * 100).toFixed(1)}%`;
const api = (url, opt) =>
  fetch(API + url, opt).then((r) => {
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  });

/* Strike zone heatmap: each cell = model's success probability at that location */
function StrikeZone({ rec, pitches = [] }) {
  const W = 300, H = 360;
  const sx = (x) => ((x + 1.5) / 3) * W;
  const sz = (z) => ((4.2 - z) / 3.6) * H;
  const probs = rec.grid.map((g) => g.prob);
  const lo = Math.min(...probs), hi = Math.max(...probs);
  const cw = (0.7 / 3) * W, ch = (0.7 / 3.6) * H;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="zone">
      <rect className="zone-box" x={sx(-0.83)} y={sz(3.5)}
        width={sx(0.83) - sx(-0.83)} height={sz(1.5) - sz(3.5)} />
      {rec.grid.map((g, i) => {
        const t = hi === lo ? 0.5 : (g.prob - lo) / (hi - lo);
        const best = g.plate_x === rec.best_location.plate_x && g.plate_z === rec.best_location.plate_z;
        return (
          <g key={i}>
            <rect x={sx(g.plate_x) - cw / 2} y={sz(g.plate_z) - ch / 2} width={cw} height={ch}
              fill={`hsl(${140 * t} 70% 42%)`} opacity={0.35 + 0.5 * t} className={best ? "best" : ""} />
            <text x={sx(g.plate_x)} y={sz(g.plate_z) + 4} textAnchor="middle" className="cell-text">
              {pct(g.prob)}
            </text>
          </g>
        );
      })}
      {pitches.filter((p) => p.plate_x != null).map((p, i) => (
        <g key={"p" + i}>
          <circle cx={sx(p.plate_x)} cy={sz(p.plate_z)} r="10" className="dot" />
          <text x={sx(p.plate_x)} y={sz(p.plate_z) + 4} textAnchor="middle" className="dot-text">{i + 1}</text>
        </g>
      ))}
    </svg>
  );
}

function Bars({ recs, current, onSelect }) {
  const max = Math.max(...recs.map((r) => r.success_prob));
  return recs.map((r) => (
    <div key={r.pitch_type} onClick={() => onSelect(r.pitch_type)}
      className={"bar-row" + (r.pitch_type === current ? " sel" : "")}>
      <span className="pt">{r.pitch_type}</span>
      <div className="bar"><div style={{ width: `${(r.success_prob / max) * 100}%` }} /></div>
      <span className="val">{pct(r.success_prob)}</span>
    </div>
  ));
}

function Results({ data, pitches }) {
  const [sel, setSel] = useState(null);
  if (!data) return <p className="muted">Loading…</p>;
  const recs = data.recommendations;
  const cur = recs.find((r) => r.pitch_type === sel) || recs[0];
  return (
    <div className="results">
      <div>
        <h3>Recommended: <span className="hl">{recs[0].pitch_type}</span></h3>
        <Bars recs={recs} current={cur.pitch_type} onSelect={setSel} />
        {data.used_default_arsenal && <p className="muted">Pitcher not in training data: using a default arsenal.</p>}
      </div>
      <div>
        <h3>{cur.pitch_type} location heatmap <small className="muted">(catcher's view)</small></h3>
        <StrikeZone rec={cur} pitches={pitches} />
      </div>
    </div>
  );
}

function Sandbox() {
  const [pitchers, setPitchers] = useState([]);
  const [pid, setPid] = useState(null);
  const [s, setS] = useState({ stand: "R", p_throws: "R", on_base: 0, balls: 0, strikes: 0, outs_when_up: 0, inning: 1 });
  const [data, setData] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [err, setErr] = useState("");
  const set = (k, v) => setS((x) => ({ ...x, [k]: v }));

  useEffect(() => {
    api("/pitchers").then((p) => { setPitchers(p); setPid(p[0]?.pitcher_id ?? null); })
      .catch((e) => setErr("Backend unreachable: " + e.message));
  }, []);

  useEffect(() => {
    if (pid == null) return;
    let alive = true;
    api("/recommend", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pitcher_id: pid, state: s }),
    }).then((d) => alive && (setData(d), setErr(""))).catch((e) => alive && setErr(e.message));
    return () => { alive = false; };
  }, [pid, s]);

  // replay mode: step through a scripted at-bat without needing a live game
  useEffect(() => {
    if (!playing) return;
    let i = 0;
    const id = setInterval(() => {
      if (i >= DEMO.length) return setPlaying(false);
      const [balls, strikes] = DEMO[i++];
      setS((x) => ({ ...x, balls, strikes }));
    }, 2500);
    return () => clearInterval(id);
  }, [playing]);

  const Sel = ({ k, opts }) => (
    <label>{k.replace("_", " ")}
      <select value={s[k]} onChange={(e) => set(k, isNaN(e.target.value) ? e.target.value : +e.target.value)}>
        {opts.map((o) => <option key={o}>{o}</option>)}
      </select>
    </label>
  );

  return (
    <>
      <div className="controls">
        <label>pitcher
          <select value={pid ?? ""} onChange={(e) => setPid(+e.target.value)}>
            {pitchers.map((p) => <option key={p.pitcher_id} value={p.pitcher_id}>{p.name}</option>)}
          </select>
        </label>
        <Sel k="p_throws" opts={["R", "L"]} />
        <Sel k="stand" opts={["R", "L"]} />
        <Sel k="balls" opts={[0, 1, 2, 3]} />
        <Sel k="strikes" opts={[0, 1, 2]} />
        <Sel k="outs_when_up" opts={[0, 1, 2]} />
        <Sel k="inning" opts={[1, 2, 3, 4, 5, 6, 7, 8, 9]} />
        <Sel k="on_base" opts={[0, 1]} />
        <button onClick={() => setPlaying(!playing)}>{playing ? "Stop" : "▶ Replay demo at-bat"}</button>
      </div>
      {err && <p className="err">{err}</p>}
      <Results data={data} />
    </>
  );
}

function Live() {
  const [games, setGames] = useState([]);
  const [pk, setPk] = useState("");
  const [snap, setSnap] = useState(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    api("/live/games").then(setGames).catch((e) => setErr("Could not load games: " + e.message));
  }, []);

  useEffect(() => {
    if (!pk) return;
    setSnap(null); setErr("");
    const es = new EventSource(`${API}/live/${pk}/stream`);
    es.onmessage = (e) => setSnap(JSON.parse(e.data));
    es.onerror = () => setErr("Stream interrupted (game may not be live).");
    return () => es.close();
  }, [pk]);

  return (
    <>
      <div className="controls">
        <label>game
          <select value={pk} onChange={(e) => setPk(e.target.value)}>
            <option value="">Select a game…</option>
            {games.map((g) => (
              <option key={g.game_pk} value={g.game_pk}>{g.away} @ {g.home} ({g.status})</option>
            ))}
          </select>
        </label>
        {games.length === 0 && !err && <span className="muted">No games today. Use Sandbox for the demo.</span>}
      </div>
      {err && <p className="err">{err}</p>}
      {snap && (
        <>
          <div className="matchup">
            <b>{snap.pitcher_name}</b> vs <b>{snap.batter_name}</b>
            <span className="badge">{snap.state.balls}-{snap.state.strikes}</span>
            <span className="badge">{snap.state.outs_when_up} out</span>
            <span className="badge">Inn {snap.state.inning}</span>
            <span className="badge">{snap.state.on_base ? "Runners on" : "Bases empty"}</span>
          </div>
          <Results data={snap.recommendation} pitches={snap.pitches_this_at_bat} />
        </>
      )}
    </>
  );
}

const post = (url, body) =>
  api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
const pp = (x) => (x == null ? "–" : pct(x));

function Stat({ label, value, sub }) {
  return (
    <div className="stat">
      <div className="stat-val">{value}</div>
      <div className="stat-label">{label}</div>
      {sub && <div className="muted">{sub}</div>}
    </div>
  );
}

function Scoreboard({ sb, title }) {
  return (
    <div className="board">
      <h3>{title} {sb?.n ? <small className="muted">({sb.n.toLocaleString()} pitches)</small> : null}</h3>
      {!sb?.n ? <p className="muted">Nothing scored yet.</p> : (
        <div className="stats">
          <Stat label="Model's top pick = actual pitch" value={pp(sb.top1_pct)} />
          <Stat label="Actual pitch in model's top 3" value={pp(sb.top3_pct)} />
          <Stat label="Model score: its top pick" value={pp(sb.avg_rec_prob)} />
          <Stat label="Model score: pitch thrown" value={pp(sb.avg_actual_prob)} />
          <Stat label="Good outcome when pitcher matched" value={pp(sb.success_matched)} sub={`n=${sb.n_matched}`} />
          <Stat label="Good outcome when not matched" value={pp(sb.success_unmatched)} sub={`n=${sb.n_unmatched}`} />
        </div>
      )}
    </div>
  );
}

function Replay() {
  const [games, setGames] = useState([]);
  const [gk, setGk] = useState("");
  const [runId, setRunId] = useState(null);
  const [idx, setIdx] = useState(0);
  const [step, setStep] = useState(null);
  const [sb, setSb] = useState(null);
  const [backtest, setBacktest] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1200);
  const [err, setErr] = useState("");
  const total = games.find((g) => String(g.game_pk) === gk)?.n_pitches ?? 0;

  useEffect(() => {
    api("/replay/games").then(setGames).catch((e) => setErr("Could not load games: " + e.message));
    api("/scoreboard?source=backtest").then(setBacktest).catch(() => {});
  }, []);

  const start = async () => {
    try {
      const r = await post("/runs", { source: "replay", label: `game ${gk}` });
      setRunId(r.run_id); setIdx(0); setStep(null); setSb(null); setErr(""); setPlaying(true);
    } catch (e) { setErr(e.message); }
  };

  useEffect(() => {
    if (!playing || runId == null) return;
    if (idx >= total) { setPlaying(false); return; }
    let alive = true;
    const t = setTimeout(async () => {
      try {
        const s = await post(`/replay/${gk}/step`, { index: idx, run_id: runId });
        if (!alive) return;
        setStep(s); setSb(s.scoreboard); setIdx(idx + 1);
      } catch (e) { setErr(e.message); setPlaying(false); }
    }, speed);
    return () => { alive = false; clearTimeout(t); };
  }, [playing, idx, runId, total, speed, gk]);

  const st = step?.state;
  return (
    <>
      <div className="controls">
        <label>held-out game
          <select value={gk} onChange={(e) => { setGk(e.target.value); setPlaying(false); setRunId(null); setStep(null); setSb(null); }}>
            <option value="">Select a game…</option>
            {games.map((g) => <option key={g.game_pk} value={g.game_pk}>{g.label}</option>)}
          </select>
        </label>
        <label>speed
          <select value={speed} onChange={(e) => setSpeed(+e.target.value)}>
            <option value={2500}>Slow</option><option value={1200}>Normal</option><option value={300}>Fast</option>
          </select>
        </label>
        <button onClick={start} disabled={!gk}>▶ Start replay</button>
        {playing && <button onClick={() => setPlaying(false)}>Pause</button>}
        {!playing && runId != null && idx > 0 && idx < total && <button onClick={() => setPlaying(true)}>Resume</button>}
        {total > 0 && <span className="muted">pitch {idx} / {total}</span>}
      </div>
      {err && <p className="err">{err}</p>}
      {step && (
        <>
          <div className="matchup">
            <b>{step.pitcher_name}</b> vs {st.stand === "L" ? "LHB" : "RHB"}
            <span className="badge">{st.balls}-{st.strikes}</span>
            <span className="badge">{st.outs_when_up} out</span>
            <span className="badge">Inn {st.inning}</span>
            <span className={"badge " + (step.matched ? "ok" : "")}>
              Model: {step.rec_pitch} · Thrown: {step.actual_pitch} {step.matched ? "✓" : ""}
            </span>
            <span className="badge">{step.actual_success ? "Good outcome" : "Not a good outcome"}</span>
          </div>
          <Results data={step} pitches={[{ plate_x: step.actual_x, plate_z: step.actual_z }]} />
        </>
      )}
      <Scoreboard sb={sb} title="This replay" />
      <Scoreboard sb={backtest} title="Full held-out backtest (python backtest.py)" />
      <p className="muted">
        The model was trained only on earlier regular-season games, so these pitches are unseen. A mismatch is not an
        error (the pitcher's choice isn't ground truth); the outcome comparison is confounded by game situation.
      </p>
    </>
  );
}

export default function App() {
  const [tab, setTab] = useState("sandbox");
  return (
    <div className="app">
      <header>
        <h1>⚾ Pitch Recommender</h1>
        <nav>
          <button className={tab === "live" ? "on" : ""} onClick={() => setTab("live")}>Live games</button>
          <button className={tab === "sandbox" ? "on" : ""} onClick={() => setTab("sandbox")}>Sandbox</button>
          <button className={tab === "replay" ? "on" : ""} onClick={() => setTab("replay")}>Replay &amp; Scoreboard</button>
        </nav>
      </header>
      {tab === "live" ? <Live /> : tab === "replay" ? <Replay /> : <Sandbox />}
    </div>
  );
}
