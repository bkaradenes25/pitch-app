# Pitch Recommender

ML-powered next-pitch recommendations from live MLB game state.

## Backend
```bash
cd backend
pip install -r requirements.txt
# put hitting_data.csv in backend/ (and optionally cached Statcast CSVs)
python train.py            # builds ./artifacts (slow: downloads Statcast + grid search)
uvicorn app:app --reload   # docs at /docs
```

## Endpoints
- `GET /pitchers` – pitchers available in the model
- `POST /recommend` – ranked pitch types + best location for a game state
- `GET /live/games` – today's games (MLB Stats API)
- `GET /live/{game_pk}` – current at-bat + recommendation
- `GET /live/{game_pk}/stream` – SSE stream of recommendations as the game changes

## Architecture
MLB Stats API -> FastAPI poller -> feature builder -> XGBoost -> ranked pitches -> React UI (+ SQLite scoreboard)

## Frontend
```bash
cd frontend
npm install
npm run dev     # http://localhost:5173  (backend must be running on :8000)
```
- **Sandbox / Replay:** set a game state manually, or press "Replay demo at-bat" to step through a scripted count sequence (works with no live game).
- **Live games:** pick a game from today's MLB schedule; recommendations stream in via Server-Sent Events as pitches are thrown.

## Data & training (2026 season)
```bash
cd backend
python get_data.py   # downloads Statcast by month into ./data (parquet, resumable)
python train.py      # trains on the regular season; postseason stays held out for demos
```

## Database & scoreboard
SQLite (`backend/pitch.db`, created automatically; stdlib only, no server or cost).
Tables: `runs` and `pitch_events` (state before the pitch, the model's call, the pitch actually thrown, the real outcome).
```bash
cd backend
python backtest.py          # scores every held-out pitch (postseason + final slice of the regular season)
```
- **Replay & Scoreboard tab:** pick a held-out game, press Start, and watch the model's call vs the real pitch with a running scoreboard.
- **Live tab:** also logs the call made before each pitch vs the pitch that followed.
- Metrics: top-1 match, actual pitch in top 3, model score for recommended vs actual pitch, and real success rate when the pitcher matched vs didn't match the model.
- Caveat: a pitcher's actual choice is not ground truth, so a mismatch isn't an error. The success-rate split compares real outcomes but is confounded by game situation.
